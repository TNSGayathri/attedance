const students = require('../models/Students');

const manualAttendence = async(req, res) =>{
    
}